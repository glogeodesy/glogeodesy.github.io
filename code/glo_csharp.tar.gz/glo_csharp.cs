﻿//#######################################################
//#author: Zhang Yong.
//#date:   2015-03-04
//#usage:  get GLONASS Satellites' Frequency Channels
// GFC2.0 updated, extending to track all new satellites, not just original 24 satellites
//#######################################################

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace glo_csharp_nas
{
    public class gfc
    {
        public int[] date = new int[3];
        public List<int> channel = new List<int>();
    }
    public class glo_csharp
    {
        List<gfc> allgfc_list = new List<gfc>();// all GFC data

        private double cal2jd(int Year, int Month, int Day)
        {
            int Y = Year;
            int M = Month;
            int D = Day;

            if (M == 1 || M == 2)
            {
                Y = Y - 1;
                M = M + 12;
            }
            int B = -2;
            if (Y > 1582 || (Y == 1582 && (M > 10 || (M == 10 && D >= 15))))
                B = Y / 400 - Y / 100;
            double JD = Math.Floor(365.25 * Y) + Math.Floor(30.6001 * (M + 1)) + D + B + 1720996.5;
            return JD;
        }

       public  glo_csharp(string glo_path)
        {
            //read glo.dat
            FileStream fs = new FileStream(glo_path, FileMode.Open, FileAccess.Read);
            StreamReader r = new StreamReader(fs, Encoding.Default);

            string line = r.ReadLine();
            while (line != null)
            {
                if (line.Contains("END OF HEADER"))
                    break;
                line = r.ReadLine();
            }
            line = r.ReadLine();
            while (line != null)
            {
                gfc temp = new gfc();
                string[] date = Regex.Split(line, " ");
                for (int i = 0; i < 3; i++)
                    temp.date[i] = int.Parse(date[i]);
                line = r.ReadLine();

                string[] channel = Regex.Split(line, " ");
                for (int i = 0; i < channel.Length; i++)
                    temp.channel.Add(int.Parse(channel[i]));
                line = r.ReadLine();
                allgfc_list.Add(temp);
            }
            //end read file
            r.Close(); fs.Close();
        }

        public gfc get_gfc_data(int year, int month, int day)
        {
            gfc re = new gfc();

            int id = -1;
            for (int i = 0; i < allgfc_list.Count - 1; i++)
            {
                double jd1 = cal2jd(allgfc_list[i].date[0], allgfc_list[i].date[1], allgfc_list[i].date[2]);
                double jd2 = cal2jd(allgfc_list[i + 1].date[0], allgfc_list[i + 1].date[1], allgfc_list[i + 1].date[2]);
                double jd = cal2jd(year, month, day);
                if (jd >= jd1 && jd < jd2)
                {
                    id = i;
                    break;
                }
                else if (jd >= jd2)
                    id = allgfc_list.Count - 1;
            }
            if (id != -1)
                re = allgfc_list[id];
            return re;
        }
    }

    /*
     * For example:
     * 
     * First, add the namespace " using glo_csharp_nas;" and the file "glo_csharp.cs" to your solution.
     *  Then, you can use the class "glo_csharp".
     * 
     *       string gpo_path = "glo.dat";
     *       int year = 2015; int month = 3; int day = 4;

     *       glo_csharp cs = new glo_csharp(gpo_path);
     *       gfc re = cs.get_gfc_data(year, month, day);
     *       for (int i = 0; i < re.channel.Count; i++)
     *          Console.Write(re.channel[i] + "  ");
  */
}
